console.log("Making Youtube related videos scrollable");

window.onload = function()
{
    setTimeout(function()
    { 
        width = window.innerWidth / 2;
        height = window.innerHeight / 2;
        if(String(document.location.href).includes('watch')){
            return document.getElementById("related").setAttribute("style","overflow:auto;height:"+ String(height) +"px;width:" + String(width) +"px");
        }else{
            return
        }
    }, 1000)
};
